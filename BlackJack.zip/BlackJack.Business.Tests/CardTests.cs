﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class CardTests
    {
        Card card;

        [TestInitialize]
        public void InitializeTest()
        {
            card = new Card();
        }

        [TestMethod]
        public void Card_Has_FaceValue_And_Suite_Properties()
        {
            card = new Card();

            var hasSuiteProperty = card.GetType().GetProperty("Suite") != null;
            var hasFaceValueProperty = card.GetType().GetProperty("FaceValue") != null;

            Assert.IsTrue(hasSuiteProperty);
            Assert.IsTrue(hasFaceValueProperty);
        }

        [TestMethod]
        public void Card_Default_FaceValue_And_Suite_Values()
        {
            card = new Card();

            Assert.IsTrue(card.Suite.Equals(Suite.Hearts));
            Assert.IsTrue(card.FaceValue.Equals(0));
        }

        [TestMethod]
        public void Card_Has_Appropriate_FaceValue_And_Suite_Values()
        {
            card = new Card(Suite.Clubs, FaceValue.Five);

            var faceValue = card.FaceValue;
            var suite = card.Suite;

            Assert.IsTrue(faceValue == (int)FaceValue.Five);
            Assert.IsTrue(suite == Suite.Clubs);
        }
    }
}
