﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class DealerTests
    {
        IHand hand;
        IDeck deck;
        Dealer dealer;

        [TestInitialize]
        public void InitializeTest()
        {
            hand = new Hand();
            deck = new Deck();

            dealer = new Dealer(deck, hand);
        }

        [TestMethod]
        public void Dealer_Has_Deck_And_Hand()
        {
            var hasDeck = dealer.GetType().GetProperty("Deck") != null;
            var hasHand = dealer.GetType().GetProperty("Hand") != null;

            Assert.IsTrue(hasDeck);
            Assert.IsTrue(hasHand);

        }        

        [TestMethod]
        public void Dealer_Has_DeckCards_And_HandCards()
        {
            var hasDeckCards = dealer.Deck.GetType().GetProperty("DeckCards") != null;
            var hasHandCards = dealer.Hand.GetType().GetProperty("HandCards") != null;

            Assert.IsTrue(hasDeckCards);
            Assert.IsTrue(hasHandCards);

        }

        [TestMethod]
        public void Dealer_Default_DeckCard_Value_And_HandCards_Value()
        {
            Assert.IsNotNull(dealer.Deck.DeckCards);
            Assert.IsTrue(dealer.Deck.DeckCards.Count == 52);
            Assert.IsNull(dealer.Hand.HandCards);
        }


    }
}
