﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class DeckTests
    {
        IDeck deck;
        [TestInitialize]
        public void TestInitialize()
        {
            deck = new Deck();
        }

        [TestMethod]
        public void Deck_Has_Collection_Of_Cards()
        {
            Assert.IsTrue(deck.GetType().GetProperty("DeckCards") != null);
        }


        [TestMethod]
        public void Deck_Has_Cards_More_Than_Zero()
        {
            Assert.IsTrue(deck.DeckCards != null);
            Assert.IsTrue(deck.DeckCards.Count > 0);
        }

        [TestMethod]
        public void Deck_Has_52_Cards()
        {           
            Assert.IsNotNull(deck.DeckCards);
            Assert.IsTrue(deck.DeckCards.Count == 52);
        }

        [TestMethod]
        public void ShuffleDeck()
        {

            var originalDeckFirstCard = deck.DeckCards.FirstOrDefault();

            deck.ShuffleDeck();

            var shuffledDeckFirstCard = deck.DeckCards.FirstOrDefault();

            Assert.AreNotEqual(originalDeckFirstCard.FaceValue, shuffledDeckFirstCard.FaceValue);
            Assert.AreNotEqual(originalDeckFirstCard.Suite, shuffledDeckFirstCard.Suite);
        }

        [TestMethod]
        public void Get_A_Card()
        {
            var firstCard = deck.GetNewCard();
            var secondCard = deck.GetNewCard();

            Assert.IsNotNull(firstCard);
            Assert.IsNotNull(secondCard);
            Assert.AreNotEqual(firstCard, secondCard);

        }

        [TestMethod]
        public void Deck_Size_Reduces_After_Getting_Card()
        {
            var firstCard = deck.GetNewCard();
            var secondCard = deck.GetNewCard();

            Assert.IsNotNull(firstCard);
            Assert.IsNotNull(secondCard);
            Assert.IsTrue(deck.DeckCards.Count == 50);

        }
    }
}
