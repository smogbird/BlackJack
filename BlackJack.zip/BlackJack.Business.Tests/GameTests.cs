﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class GameTests
    {
        [TestMethod]
        public void Game_Has_Dealer_Player()
        {
            var hand = new Hand();
            var deck = new Deck();

            var dealer = new Dealer(deck, hand);
            var player = new Player(hand, String.Empty);

            var game = new Game(dealer, player);

            var hasDealer = game.GetType().GetProperty("Dealer") != null;
            var hasPlayer = game.GetType().GetProperty("Player") != null;

            Assert.IsTrue(hasDealer);
            Assert.IsTrue(hasPlayer);
        }

        [TestMethod]
        public void Game_Player_Has_GivenName()
        {
            var hand = new Hand();
            var deck = new Deck();
            var name = "Player1";

            var dealer = new Dealer(deck, hand);
            var player = new Player(hand, name);

            var game = new Game(dealer, player);

            Assert.IsTrue(game.Player.Name.Equals(name));
        }

        [TestMethod]
        public void GetInitialDeal()
        {
            var hand = new Hand();
            var deck = new Deck();
            var name = "Player1";

            var dealer = new Dealer(deck, hand);
            var player = new Player(hand, name);

            var playerCards = new List<Card>();

            playerCards.Add(deck.GetNewCard());
            playerCards.Add(deck.GetNewCard());

            Assert.IsTrue(playerCards.Count == 2);
            Assert.AreNotEqual(playerCards.First(), playerCards.Last());

            player.Hand.HandCards = playerCards;

            var dealerCards = new List<Card>();

            dealerCards.Add(deck.GetNewCard());
            dealerCards.Add(deck.GetNewCard());

            Assert.IsTrue(dealerCards.Count == 2);
            Assert.AreNotEqual(dealerCards.First(), dealerCards.Last());

            dealer.Hand.HandCards = dealerCards;

            

        }
    }
}
