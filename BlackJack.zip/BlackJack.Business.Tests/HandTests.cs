﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class HandTests
    {
        [TestMethod]
        public void Hand_Has_Collection_Of_Cards()
        {
            IHand hand = new Hand();

            Assert.IsTrue(hand.GetType().GetProperty("HandCards") != null);
        }
    }
}
