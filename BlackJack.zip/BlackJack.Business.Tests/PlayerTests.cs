﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlackJack.Business.Tests
{
    [TestClass]
    public class PlayerTests
    {
        [TestMethod]
        public void Player_Has_Hand_And_Name()
        {
            Hand hand = new Hand();
            string name = string.Empty;

            Player player = new Player(hand, name);

            var hasHand = player.GetType().GetProperty("Hand") != null;
            var hasName = player.GetType().GetProperty("Name") != null;

            Assert.IsTrue(hasHand);
            Assert.IsTrue(hasName);

        }

        [TestMethod]
        public void Player_Returns_Given_Name()
        {
            Hand hand = new Hand();
            string name = "PlayerName";

            Player player = new Player(hand, name);

            Assert.IsTrue(player.Name.Equals(name));

        }
    }
}
