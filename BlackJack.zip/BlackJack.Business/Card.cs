﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    public class Card
    {
        /// <summary>
        /// Card has a facevalue and a suite value
        /// The values are from enums
        /// </summary>
        
        public int FaceValue { get; private set; }
        public Suite Suite { get; private set; }

        public Card()
        {

        }

        public Card(Suite suite, FaceValue faceValue)
        {
            Suite = suite;
            FaceValue = (int)faceValue;
        }
    }
}
