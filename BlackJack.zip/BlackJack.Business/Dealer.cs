﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    public class Dealer: IDealer
    {
        /// <summary>
        /// Dealer starts the game
        /// Starts by dealing two cards for player and two cards for dealer
        /// </summary>
        
        public IDeck Deck { get; set; }
        public IHand Hand { get; set; }

        public Dealer(IDeck deck, IHand hand)
        {
            Deck = deck;
            Hand = hand;
        }
    }
}
