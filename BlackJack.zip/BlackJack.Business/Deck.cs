﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    public class Deck : IDeck
    {
        /// <summary>
        /// Contains a collection of cards
        /// Be able to Shuffle the deck and get a random card from deck
        /// </summary>
        
        public IList<Card> DeckCards { get; set; }

        public Deck()
        {
            DeckCards = GetDeckCards();
        }

        private IList<Card> GetDeckCards()
        {
            var suites = Enum.GetValues(typeof(Suite)).Cast<Suite>();
            var faceValues = Enum.GetValues(typeof(FaceValue)).Cast<FaceValue>();
            DeckCards = new List<Card>();

            foreach(var suite in suites)
            {
                foreach(var value in faceValues)
                {
                    DeckCards.Add(new Card(suite, value));
                }
            }

            return DeckCards;
        }

        public void ShuffleDeck()
        {
            //Do simple shuffle
            DeckCards = DeckCards.OrderByDescending(x => x.Suite).ThenByDescending(y => y.FaceValue).ToList();
        }

        public Card GetNewCard()
        {
            Card card = null;

            while (card == null)
            {
                Random r = new Random();
                var randValue = r.Next(2, 12);
                var randSuite = r.Next(1, 5);

                card = DeckCards.Where(x => x.FaceValue == randValue && x.Suite == (Suite)randSuite).FirstOrDefault();

                DeckCards.Remove(card);
            }

            return card;
        }
    }
}
