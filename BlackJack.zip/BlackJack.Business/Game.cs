﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    public class Game : IGame
    {
        /// <summary>
        /// Game has a dealer and player
        /// Has the functionlaity for start game
        /// </summary>
        public IDealer Dealer { get; set; }
        public IPlayer Player { get; set; }
        public Game(IDealer dealer, IPlayer player)
        {
            Dealer = dealer;
            Player = player;
        }

        public void GetInitialDeal()
        {
            //ShuffleCards();
            //Player.Hand = Dealer.DealIntialCards();

        }
    }
}
