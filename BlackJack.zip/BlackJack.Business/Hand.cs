﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    /// <summary>
    /// Hand contains a list of cards start with two and increasing one by one
    /// Hand will be used for both dealer and player
    /// </summary>
    
    public class Hand : IHand
    {
        public IList<Card> HandCards { get; set; }
    }
}
