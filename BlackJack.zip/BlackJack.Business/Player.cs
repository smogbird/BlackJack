﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Business
{
    public class Player : IPlayer
    {
        /// <summary>
        /// Player has a name and a Hand
        /// At the start of the game player gets two cards and one after another 
        /// each time when player does a hit
        /// </summary>

        public string Name { get; set; }

        public Hand Hand { get; set; }

        public Player(Hand hand, string name)
        {
            Hand = hand;
            Name = name;
        }
    }
}
